﻿
@echo off
title Docsify 로컬 서버 실행기
:: [추가] 배치 파일이 있는 폴더 경로로 강제 이동
cd /d "%~dp0"
chcp 65001 > nul

echo ==================================================
echo       Docsify 로컬 뷰어 서버를 시작합니다.
echo ==================================================
echo.
echo  1. 잠시 후 기본 브라우저가 자동으로 열립니다.
echo     (자동으로 열리지 않으면 아래 주소로 접속하세요)
echo     👉 http://localhost:8000
echo.
echo  2. 서버를 종료하려면 이 창에서 [Ctrl + C]를 누르거나
echo     이 창을 닫아주세요.
echo ==================================================
echo.

:: 1초 대기 후 브라우저 자동 실행
timeout /t 1 /nobreak > nul
start http://localhost:8000

:: 파이썬 로컬 서버 실행
python -m http.server 8000

pause