﻿"""
agent_skills.py
Antigravity Blog Writer Agent를 위한 6대 핵심 스킬 모듈 (가독성/폰트 크기 검증 강화 버전)
"""

import ast
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional


# ==============================================================================
# Skill 1. 소스 데이터 프로파일러 & 로더
# ==============================================================================
def data_profiler(file_path: str) -> Dict[str, Any]:
    """
    /workspace/ 내의 데이터 파일(.csv, .json, .parquet, .py 등)을 분석하여
    스키마, 결측치, 기술통계량 및 핵심 통계 요약본을 반환합니다.
    """
    if not os.path.exists(file_path):
        return {"status": "error", "message": f"파일을 찾을 수 없습니다: {file_path}"}

    ext = os.path.splitext(file_path)[1].lower()
    try:
        if ext == ".csv":
            import pandas as pd
            df = pd.read_csv(file_path)
            return {
                "status": "success",
                "file_type": "csv",
                "shape": df.shape,
                "columns": list(df.columns),
                "missing_values": df.isnull().sum().to_dict(),
                "numeric_summary": df.describe().to_dict(),
                "head": df.head(3).to_dict(orient="records"),
            }
        elif ext == ".json":
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return {
                "status": "success",
                "file_type": "json",
                "keys": list(data.keys()) if isinstance(data, dict) else f"List with {len(data)} items",
                "preview": str(data)[:1000]
            }
        elif ext in [".py", ".txt", ".md"]:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            return {
                "status": "success",
                "file_type": ext,
                "line_count": len(content.splitlines()),
                "preview": content[:1500]
            }
        else:
            return {"status": "error", "message": f"지원하지 않는 파일 형식입니다: {ext}"}
    except Exception as e:
        return {"status": "error", "message": f"데이터 프로파일링 중 오류 발생: {str(e)}"}


# ==============================================================================
# Skill 2. SVG 문법, 텍스트 예산제 및 최소 폰트 가독성 정적 검사기
# ==============================================================================
def svg_layout_validator(
    svg_content: str, 
    max_text_len: int = 24, 
    min_font_size: float = 13.5
) -> Dict[str, Any]:
    """
    SVG XML 문법, viewBox 설정, 텍스트 예산제(글자 수 상한), 그리고 최소 폰트 크기(가독성)를 검사합니다.
    """
    issues = []
    warnings = []

    # 1. XML 문법 검사
    try:
        root = ET.fromstring(svg_content)
    except ET.ParseError as e:
        return {
            "valid": False,
            "status": "syntax_error",
            "errors": [f"SVG XML 파싱 에러: {str(e)}"]
        }

    # 2. 필수 속성(viewBox / width / height) 검사
    viewbox = root.attrib.get("viewBox")
    if not viewbox:
        issues.append("viewBox 속성이 누락되어 반응형 렌더링에 문제가 발생할 수 있습니다.")

    # 3. 비호환 태그 검사 (foreignObject 금지)
    for elem in root.iter():
        tag_name = elem.tag.split("}")[-1]
        if tag_name == "foreignObject":
            issues.append("<foreignObject> 태그는 이미지 렌더러 호환성을 위해 사용할 수 없습니다.")

    # 4. 텍스트 예산 및 최소 폰트 크기(가독성) 검사
    for elem in root.iter():
        tag_name = elem.tag.split("}")[-1]
        if tag_name in ["text", "tspan"]:
            text_str = "".join(elem.itertext()).strip()
            if not text_str:
                continue

            # (1) 텍스트 길이 검사
            if len(text_str) > max_text_len:
                warnings.append(
                    f"텍스트 예산 초과(권장 {max_text_len}자 이하): '{text_str}' ({len(text_str)}자) - 1줄 핵심어로 압축 필요"
                )

            # (2) 폰트 크기 하한선 검사
            font_size_attr = elem.attrib.get("font-size")
            if not font_size_attr:
                style_attr = elem.attrib.get("style", "")
                m = re.search(r"font-size\s*:\s*([\d\.]+)px?", style_attr)
                if m:
                    font_size_attr = m.group(1)

            if font_size_attr:
                try:
                    fs = float(re.sub(r"[^\d\.]", "", font_size_attr))
                    if fs < min_font_size:
                        warnings.append(
                            f"가독성 저하 경고 (최소 {min_font_size}px 권장): '{text_str}' (현재 {fs}px) - 모바일/웹 가독성을 위해 14~15px 이상으로 키워주세요."
                        )
                except ValueError:
                    pass

    return {
        "valid": len(issues) == 0,
        "syntax_ok": True,
        "viewBox": viewbox,
        "issues": issues,
        "warnings": warnings,
        "status": "ready_for_preview" if len(issues) == 0 and len(warnings) == 0 else "needs_refinement"
    }


# ==============================================================================
# Skill 3. Python 샌드박스 런타임 실행기
# ==============================================================================
def python_sandbox_runner(code_str: str, timeout_sec: int = 10) -> Dict[str, Any]:
    """
    Python 코드를 독립된 프로세스에서 실행하여 표준 출력, 에러, 실행 시간 및 그래프 렌더링 여부를 검증합니다.
    """
    agg_header = "import matplotlib\nmatplotlib.use('Agg')\n"
    executable_code = agg_header + code_str

    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as tf:
        tf.write(executable_code)
        temp_path = tf.name

    try:
        res = subprocess.run(
            [sys.executable, temp_path],
            capture_output=True,
            text=True,
            timeout=timeout_sec
        )
        return {
            "success": res.returncode == 0,
            "returncode": res.returncode,
            "stdout": res.stdout,
            "stderr": res.stderr,
            "has_runtime_error": res.returncode != 0
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "returncode": -1,
            "stdout": "",
            "stderr": f"Execution timed out ({timeout_sec}초 초과).",
            "has_runtime_error": True
        }
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


# ==============================================================================
# Skill 4. 브라우저 Pyodide 호환성 린터
# ==============================================================================
def pyodide_compatibility_linter(code_str: str) -> Dict[str, Any]:
    """
    브라우저 환경(Pyodide)에서 실행 불가능한 패키지, 로컬 파일 I/O, 서브프로세스 등을 AST 파싱으로 검출합니다.
    """
    unsupported_modules = {
        "subprocess", "multiprocessing", "threading", "socket", 
        "os.system", "tkinter", "pyautogui", "pynput"
    }
    banned_calls = {"open", "execfile"}
    
    issues = []
    
    try:
        tree = ast.parse(code_str)
    except SyntaxError as e:
        return {
            "compatible": False,
            "status": "syntax_error",
            "errors": [f"Python 문법 오류: {str(e)}"]
        }

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name in unsupported_modules:
                    issues.append(f"Pyodide 미지원 모듈 import 발견: `{alias.name}`")
        elif isinstance(node, ast.ImportFrom):
            if node.module in unsupported_modules:
                issues.append(f"Pyodide 미지원 모듈 import 발견: `{node.module}`")
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in banned_calls:
                issues.append(
                    "브라우저 환경에서는 로컬 `open()` 파일 접근이 불가능합니다. "
                    "하드코딩된 정적 데이터(Dict/List)나 인메모리 문자열(io.StringIO)을 사용하세요."
                )

    return {
        "compatible": len(issues) == 0,
        "issues": issues,
        "message": "Pyodide 호환성 검사 통과" if len(issues) == 0 else "Pyodide 호환성 결격 사유 발견"
    }


# ==============================================================================
# Skill 5. 기술 통계 팩트체크 검색 (인터페이스 모듈)
# ==============================================================================
def web_factcheck_search(query: str) -> Dict[str, Any]:
    """
    통계 공식, 최신 패키지 API 시그니처, 팩트체크 기사 등을 웹에서 검색합니다.
    """
    return {
        "query": query,
        "note": "통계 레퍼런스 및 팩트체크를 위한 외부 검색 엔드포인트입니다.",
        "search_hint": f"검색어 [{query}]에 대한 공신력 있는 공식 문서 및 통계 논문 위주로 팩트체크를 수행합니다."
    }


# ==============================================================================
# Skill 6. 티스토리 맞춤형 마크다운 포맷터
# ==============================================================================
def tistory_post_formatter(
    markdown_content: str,
    image_mappings: Optional[Dict[str, str]] = None,
    add_toc: bool = True
) -> str:
    """
    마크다운 포스트를 티스토리 스킨 친화적으로 변환합니다:
    1. [여기에 *.png 삽입] 플레이스홀더를 HTML 캡션 이미지 블록으로 치환
    2. Python 코드 블록에 Pyodide 인터랙티브 실행 태그 삽입
    3. 본문 상단에 자동 목차(TOC) 생성
    """
    formatted = markdown_content
    image_mappings = image_mappings or {
        "intro_problem.png": "intro_problem.svg",
        "body_main.png": "body_main.svg",
        "conclusion_summary.png": "conclusion_summary.svg"
    }

    # 1. 이미지 플레이스홀더 치환
    for png_name, svg_file in image_mappings.items():
        placeholder = f"[여기에 {png_name} 삽입]"
        replacement = (
            f'\n<div class="infographic-container" style="text-align: center; margin: 2rem 0;">\n'
            f'  <img src="./{svg_file}" alt="{png_name}" style="max-width: 100%; height: auto; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-radius: 8px;" />\n'
            f'  <p class="caption" style="color: #666; font-size: 0.9rem; margin-top: 0.5rem;">▲ {png_name.replace(".png", "")} 인포그래픽 분석</p>\n'
            f'</div>\n'
        )
        formatted = formatted.replace(placeholder, replacement)

    # 2. Python 코드 블록에 인터랙티브 실행 태그 래핑
    code_block_pattern = r"```python(.*?)```"
    
    def replacer(match):
        code_body = match.group(1)
        return f'<div class="pyodide-runnable" data-executable="true">\n\n```python{code_body}```\n</div>'

    formatted = re.sub(code_block_pattern, replacer, formatted, flags=re.DOTALL)

    # 3. 자동 목차(TOC) 생성
    if add_toc:
        headings = re.findall(r"^(#{2,3})\s+(.+)$", markdown_content, re.MULTILINE)
        if headings:
            toc_md = "### 📌 목차 (Table of Contents)\n"
            for hashes, title in headings:
                indent = "  " if len(hashes) == 3 else ""
                toc_md += f"{indent}- {title}\n"
            toc_md += "\n---\n\n"
            first_h2 = re.search(r"^##\s+", formatted, re.MULTILINE)
            if first_h2:
                idx = first_h2.start()
                formatted = formatted[:idx] + toc_md + formatted[idx:]

    return formatted