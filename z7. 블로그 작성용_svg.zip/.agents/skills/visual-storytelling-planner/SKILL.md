﻿# Skill: Visual Storytelling Planner (AntV-Inspired)

## 목적
AntV Infographic의 정보 구조화 템플릿 분류 체계를 적용하여, 기술 블로그의 맥락에 가장 최적화된 시각화 다이어그램을 기획합니다.

## 섹션별 추천 템플릿 및 기획 지침

1. **서론 (문제 제기 및 배경) -> `intro_problem.svg`**
   - **적용 템플릿:** `compare-binary-*` (A/B 대비) 또는 `sequence-timeline-*`
   - **기획 콘셉트:** 
     - "직관/소문 기반의 판단(Before)" vs "데이터 기반의 통계적 팩트체크(After)"를 좌우 2분할 카드로 명확히 대비.
     - 표본 누락 및 편향된 해석의 위험성을 시각화.

2. **본문 (핵심 기술 및 분석 절차) -> `body_main.svg`**
   - **적용 템플릿:** `sequence-horizontal-zigzag-*` (단계별 플로우) 또는 `hierarchy-tree-*` (아키텍처)
   - **기획 콘셉트:**
     - 원본 소스 데이터 수집 -> Python 통계 모델 적용(p-value, t-test, 카이제곱) -> 유의성 판정으로 이어지는 논리적 파이프라인 시각화.

3. **결론 (요약 및 제언) -> `conclusion_summary.svg`**
   - **적용 템플릿:** `list-grid-badge-card` (핵심 원칙 카드 그리드) 또는 `quadrant-*` (4분면 매트릭스)
   - **기획 콘셉트:**
     - 독자가 기억해야 할 '데이터 팩트체크 3대 원칙' 또는 '분석 체크리스트'를 깔끔한 3~4개의 요약 카드로 정리.