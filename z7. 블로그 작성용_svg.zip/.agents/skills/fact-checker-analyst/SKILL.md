﻿---
name: fact-checker-analyst
description: 입력 문서 데이터 분석 및 통계적 유의성 검증/팩트체크 가이드라인
---

# Fact Checker & Data Analyst Skill

## Purpose
제공된 소스 파일(PDF, Excel, TXT 등)에서 구체적인 수치와 검증 방법론을 추출하고, 직관적 판단과 통계적 유의성 검증의 차이를 명확히 분석하며, 브라우저에서 즉시 재현 가능한 완전한 Python 검증 코드를 작성합니다.

## Core Rules

### 1. [실제 데이터 중심 정밀 파싱]
- 가상의 수치나 임의의 예제를 생성하지 않습니다.
- `/workspace/`에 마운트된 문서(예: `유의성 검증.pdf`, 표, 데이터 세트)에 등장하는 실제 표본 크기($N$), 승률, 수익률, 관측 빈도, p-value 등을 원본 그대로 정확히 인용합니다.

### 2. [통계적 유의성 검증 방법론 명시]
- 단순 산술평균 비교나 표면적 수익률의 직관적 착시가 내포한 위험성을 수학적으로 지적합니다.
- 가설 검정(Hypothesis Testing), t-검정(t-test), 카이제곱 독립성 검정($\chi^2$-test), 스피어만/피어슨 상관분석 등 통계적 기법을 통해 실제 유의미한 차이(Statistical Significance)가 성립하는지 명확히 판정합니다.

### 3. [Python 실전 코드 제공 및 Self-Contained 원칙]
블로그 본문에 수록되는 Python 코드는 **'본문 해설용 분할 스니펫'**과 **'최종 통합 실행 코드'**의 2가지 형태로 구분하여 완벽히 작성합니다.

#### 💡 (A) 본문 해설용 단계별 스니펫 (Snippets)
- 독자가 수식과 로직을 한 단계씩 이해할 수 있도록 기능 단위로 분할합니다.
- 각 스니펫 상단에 주석(`# 단계 설명`)을 달아 어떤 변수가 다루어지는지 명확히 표시합니다.

#### 🚀 (B) 전체 통합 실행 코드 (Full Standalone Script) - 브라우저 플레이그라운드 호환
- **필수 라이브러리 명시적 임포트**: `import numpy as np`, `import pandas as pd`, `from scipy import stats`, `import matplotlib.pyplot as plt` 등을 최상단에 누락 없이 선언합니다.
- **정적 데이터셋 내장(Self-Contained)**: 외부 로컬 파일 읽기(`pd.read_csv('C:/...')`)나 사용자 입력 대기(`input()`)를 배제하고, 분석 대상 데이터를 `np.array` 또는 `pd.DataFrame` 형태로 직접 선언하여 초기화합니다.
- **실행 결과 출력 표준화**:
  - `print()` 함수를 활용하여 통계량(t-statistic, $\chi^2$, $\rho$), p-value, 귀무가설 기각 여부 판단 문구를 일목요연하게 포맷팅(`f-string`) 출력합니다.
  - 그래프 시각화가 포함된 경우 `plt.figure(...)` 설정과 함께 마지막에 `plt.show()`를 반드시 명시하여 Pyodide 이미지 변환기가 그래프를 정상 캡처하도록 합니다.