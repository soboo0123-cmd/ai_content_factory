﻿import ast
import base64
import json
import os
import re
import shutil
import sys
import time
import warnings
from datetime import datetime
from google import genai
from google.genai import types

# 구글 SDK 내부의 실험적 기능 경고 숨김 처리
warnings.filterwarnings("ignore")

def load_config(file_path="config.txt"):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"설정 파일을 찾을 수 없습니다: {file_path}")

    with open(file_path, "r", encoding="utf-8-sig") as f:
        content = f.read()

    clean_lines = [line for line in content.splitlines() if not line.strip().startswith("#")]
    clean_content = "\n".join(clean_lines)
    config = {}

    api_key_match = re.search(r"GEMINI_API_KEY\s*=\s*[\"']?([^\"'\n]+)[\"']?", clean_content)
    if api_key_match:
        config["GEMINI_API_KEY"] = api_key_match.group(1).strip()

    agent_match = re.search(r"agent\s*=\s*[\"']?([^\"'\n]+)[\"']?", clean_content)
    if agent_match:
        config["agent"] = agent_match.group(1).strip()

    agent_config_match = re.search(r"agent_config\s*=\s*(\{.*?\})", clean_content, re.DOTALL)
    if agent_config_match:
        dict_str = agent_config_match.group(1).strip()
        try:
            config["agent_config"] = ast.literal_eval(dict_str)
        except Exception:
            try:
                clean_dict = re.sub(r",\s*([\}\]])", r"\1", dict_str)
                config["agent_config"] = json.loads(clean_dict)
            except Exception:
                pass

    return config


def load_input(file_path="input.txt"):
    """input.txt 파일 내용 읽기 및 file: 경로 파싱"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"입력 파일을 찾을 수 없습니다: {file_path}")

    with open(file_path, "r", encoding="utf-8-sig") as f:
        raw_content = f.read()

    file_paths = []
    text_lines = []

    for line in raw_content.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("file:"):
            path = stripped[5:].strip().strip("\"'")
            if path:
                file_paths.append(path)
        else:
            text_lines.append(line)

    user_input = "\n".join(text_lines).strip()
    return user_input, file_paths


# --- 파일 변환 및 환경 전처리 함수 ---

def load_agent_and_skills_sources():
    """ .agents/AGENTS.md 및 .agents/skills/ 내부 마크다운 파일들을 읽어서 sources 구성 """
    agent_sources = []
    
    agents_md_path = os.path.join(".agents", "AGENTS.md")
    if os.path.exists(agents_md_path):
        with open(agents_md_path, "r", encoding="utf-8") as f:
            content = f.read()
        agent_sources.append({"type": "inline", "target": ".agents/AGENTS.md", "content": content})
        print(f"  [에이전트 지침] 마운트 준비 완료: .agents/AGENTS.md")

    skills_dir = os.path.join(".agents", "skills")
    if os.path.exists(skills_dir):
        for root, _, files in os.walk(skills_dir):
            for file in files:
                if file.lower().endswith(".md"):
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, ".").replace("\\", "/")
                    with open(full_path, "r", encoding="utf-8") as f:
                        content = f.read()
                    agent_sources.append({"type": "inline", "target": rel_path, "content": content})
                    print(f"  [스킬 정의] 마운트 준비 완료: {rel_path}")
    return agent_sources


def prepare_environment_sources(file_paths: list):
    """텍스트/마크다운 소스는 inline 마운트로 준비하고, PDF 등 바이너리는 직접 업로드 목록으로 분리"""
    sources = []
    print("\n[안내] 에이전트/스킬 및 텍스트 소스 분석, 샌드박스 마운트 준비:")
    sources.extend(load_agent_and_skills_sources())

    binary_files = []
    for file_path in file_paths:
        if not os.path.exists(file_path):
            print(f"  ❌ [경고] 파일을 찾을 수 없습니다: {file_path}")
            continue

        file_name = os.path.basename(file_path)
        ext = os.path.splitext(file_name)[1].lower()
        target_path = f"/workspace/{file_name}"

        # 텍스트 계열 파일은 인라인 소스로 마운트
        if ext in ['.txt', '.md', '.csv', '.json', '.py', '.js', '.html']:
            content = None
            for enc in ('utf-8', 'euc-kr', 'cp949'):
                try:
                    with open(file_path, "r", encoding=enc) as f:
                        content = f.read()
                    break
                except Exception:
                    continue
            if content is not None:
                sources.append({"type": "inline", "content": content, "target": target_path})
                print(f"  [텍스트 소스] 인라인 마운트 완료: {file_path}")
            else:
                print(f"  [오류] 텍스트 인코딩 읽기 실패: {file_path}")
        else:
            # PDF 및 기타 바이너리 파일은 원본 그대로 전송하기 위해 목록에 보관
            binary_files.append((file_path, file_name, ext))
            print(f"  [바이너리 원본 대기] 샌드박스 직접 업로드 대상: {file_path}")

    return sources, binary_files


def upload_binary_files_to_sandbox(client, environment_id: str, binary_files: list):
    """Files API를 통해 원본 PDF 파일을 샌드박스(/workspace/)에 바이너리 그대로 직접 업로드"""
    if not binary_files or not environment_id:
        return

    print(f"\n[안내] 샌드박스({environment_id})에 원본 바이너리 파일 직접 전송 중...")
    for file_path, file_name, ext in binary_files:
        remote_path = f"workspace/{file_name}"
        mime_type = "application/pdf" if ext == '.pdf' else "application/octet-stream"
        
        try:
            if hasattr(client, "environments") and hasattr(client.environments, "files"):
                with open(file_path, "rb") as f:
                    client.environments.files.upload(
                        environment=environment_id,
                        path=remote_path,
                        file=f,
                        mime_type=mime_type,
                        overwrite=True,
                    )
                print(f"  ✅ [원본 업로드 성공] /workspace/{file_name} (MIME: {mime_type})")
            else:
                print(f"  ⚠️ [안내] SDK 버전 제약으로 Files API를 직접 호출할 수 없습니다.")
        except Exception as e:
            print(f"  ⚠️ [업로드 경고] 원본 바이너리 전송 중 예외: {e}")


# --- Custom Tools ---

def save_blog_post(output_dir: str, filename: str, content: str) -> dict:
    """[Custom Tool 1] 최종 완성된 블로그 글(.md)을 단일 출력 폴더에 저장합니다."""
    print(f"\n[Tool 실행] 블로그 글 저장 중... -> 대상: {filename}")
    try:
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"  [성공] 블로그 글 저장 완료: {filepath}")
        return {"status": "success", "saved_path": filepath, "message": "블로그 글이 성공적으로 저장되었습니다."}
    except Exception as e:
        print(f"  [오류] 블로그 파일 저장 중 예외 발생: {e}")
        return {"status": "error", "error_message": str(e)}


def save_infographic(output_dir: str, filename: str, svg_content: str) -> dict:
    """[Custom Tool 2] SVG 코드를 저장하고 PyMuPDF를 통해 상하 여백 없이 정확한 비율의 고해상도 PNG로 변환합니다."""
    print(f"\n[Tool 실행] 인포그래픽 저장 중... -> 대상: {filename}")
    try:
        base_name = os.path.splitext(filename)[0]
        svg_filename = f"{base_name}.svg"
        png_filename = f"{base_name}.png"
        
        svg_filepath = os.path.join(output_dir, svg_filename)
        png_filepath = os.path.join(output_dir, png_filename)

        # [상하여백 방지 자동 전처리] viewBox 파싱 후 100%를 명시적 픽셀로 강제 변환
        viewbox_match = re.search(r'viewBox=["\']\s*(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s*["\']', svg_content)
        if viewbox_match:
            _, _, vb_w, vb_h = viewbox_match.groups()
            vb_w_int = int(float(vb_w))
            vb_h_int = int(float(vb_h))
            
            svg_content = re.sub(r'width=["\']100%["\']', f'width="{vb_w_int}"', svg_content)
            svg_content = re.sub(r'height=["\']100%["\']', f'height="{vb_h_int}"', svg_content)
            
            if 'width=' not in svg_content[:150] and 'height=' not in svg_content[:150]:
                svg_content = svg_content.replace('<svg', f'<svg width="{vb_w_int}" height="{vb_h_int}"', 1)
        
        # 1. 전처리된 SVG 원본 파일 저장
        with open(svg_filepath, "w", encoding="utf-8") as f:
            f.write(svg_content)
        
        # 2. PyMuPDF(pymupdf)를 통한 1:1 무여백 고화질 PNG 렌더링
        try:
            import pymupdf
            doc = pymupdf.open(svg_filepath)
            page = doc[0]
            pix = page.get_pixmap(dpi=150)
            pix.save(png_filepath)
            doc.close()
            msg = f"SVG 및 PNG 무여백 고화질 변환 완료 (경로: {png_filename})"
        except ImportError:
            msg = f"SVG 파일 저장 완료 (pymupdf 미설치로 PNG 변환 생략)"
        except Exception as conv_err:
            msg = f"SVG 파일 저장 완료, PNG 변환 중 오류: {conv_err}"

        print(f"  [성공] {msg}")
        return {"status": "success", "saved_png_filename": png_filename, "message": msg}
    except Exception as e:
        print(f"  [오류] 인포그래픽 저장 중 예외 발생: {e}")
        return {"status": "error", "error_message": str(e)}


def _extract_environment_id(interaction, default_environment):
    """interaction 객체로부터 할당된 environment_id 문자열을 안전하게 추출하여 세션을 재사용"""
    env_id = None
    if hasattr(interaction, "environment"):
        env_val = getattr(interaction, "environment")
        if isinstance(env_val, str):
            env_id = env_val
        elif hasattr(env_val, "id") and getattr(env_val, "id"):
            env_id = getattr(env_val, "id")
        elif isinstance(env_val, dict) and env_val.get("id"):
            env_id = env_val.get("id")

    if not env_id and hasattr(interaction, "environment_id"):
        env_id = getattr(interaction, "environment_id")

    return env_id if env_id else default_environment


# --- 429 Rate Limit 및 일시적 서버 오류 방지용 재시도 래퍼 함수 ---

def create_interaction_with_retry(client, max_retries=5, **kwargs):
    """429 Rate Limit 및 500/503 일시적 서버 오류 발생 시 대기 후 자동 재시도"""
    for attempt in range(1, max_retries + 1):
        try:
            return client.interactions.create(**kwargs)
        except Exception as e:
            err_str = str(e)
            if "429" in err_str or "quota" in err_str.lower() or "rate" in err_str.lower():
                wait_time = 35
                match = re.search(r"retry in (\d+(?:\.\d+)?)s", err_str)
                if match:
                    wait_time = int(float(match.group(1))) + 5
                
                print(f"\n  ⏳ [API 한도 대기] 분당 호출 제한(429). {wait_time}초 대기 후 재시도... (시도 {attempt}/{max_retries})")
                time.sleep(wait_time)
            elif ("500" in err_str or "503" in err_str or "internal" in err_str.lower()) and attempt < max_retries:
                wait_time = 5 * attempt
                err_preview = (err_str[:120] + '...') if len(err_str) > 120 else err_str
                print(f"\n  ⚠️ [서버 내부 일시 오류 감지: {err_preview}] {wait_time}초 대기 후 자동 재시도... (시도 {attempt}/{max_retries})")
                time.sleep(wait_time)
            else:
                raise e
    raise RuntimeError(f"최대 재시도 횟수({max_retries}회)를 초과했습니다.")


# --- Main 실행 로직 ---

def main():
    print("[1/4] 환경 설정 및 입력 파일(input.txt) 분석 중...")

    try:
        config = load_config("config.txt")
        api_key = config.get("GEMINI_API_KEY")
        agent_id = config.get("agent", "antigravity-preview-09-2026")
        agent_config = config.get("agent_config")

        if not api_key or api_key == "your_gemini_api_key_here":
            raise ValueError("config.txt에 올바른 GEMINI_API_KEY를 설정해주세요.")

        user_input, file_paths = load_input("input.txt")
        if not user_input:
            user_input = "첨부된 소스코드/문서를 바탕으로 전문적인 기술 블로그 글을 작성해주세요."

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        OUTPUT_DIR = os.path.join("output", f"blog_output_{timestamp}")
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        print(f" - 출력 대상 폴더 생성 완료: {OUTPUT_DIR}/")

        client = genai.Client(api_key=api_key)

        # 1. 텍스트 소스 마운트와 원본 바이너리(PDF) 목록 분리 준비
        inline_sources, binary_files = prepare_environment_sources(file_paths)
        environment_param = {"type": "remote", "sources": inline_sources} if inline_sources else "remote"

        print("\n[2/4] Antigravity 에이전트 구동 시작 (.agents/AGENTS.md 및 skills 활용)...")

        tool_save_post = {
            "type": "function",
            "name": "save_blog_post",
            "description": "최종 완성된 블로그 마크다운 글을 저장합니다.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string", "description": "저장할 마크다운 파일명 (예: 'statistical_significance_blog.md')"},
                    "content": {"type": "string", "description": "작성된 블로그 글 전체 내용 (마크다운 포맷)"}
                },
                "required": ["filename", "content"]
            }
        }

        tool_save_infographic = {
            "type": "function",
            "name": "save_infographic",
            "description": "생성된 인포그래픽 SVG 코드를 파일로 저장하고 PNG 이미지로 변환합니다. (반드시 3회 호출)",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string", "description": "저장할 파일명 (예: 'intro_problem.svg', 'body_main.svg', 'conclusion_summary.svg')"},
                    "svg_content": {"type": "string", "description": "완성된 유효한 SVG XML 코드 전체"}
                },
                "required": ["filename", "svg_content"]
            }
        }

        all_tools = [tool_save_post, tool_save_infographic]

        kwargs = {
            "agent": agent_id,
            "input": user_input,
            "environment": environment_param,
            "tools": all_tools,
            "store": True,  # 👈 [1차 턴 세션 저장 활성화]
        }

        if agent_config:
            kwargs["agent_config"] = agent_config

        # 1차 Interaction 요청 생성
        interaction = create_interaction_with_retry(client, **kwargs)

        # [PDF 원본 전송] 프로비저닝된 샌드박스에 원본 PDF 바이너리를 직접 업로드
        env_id = _extract_environment_id(interaction, None)
        if env_id and binary_files:
            upload_binary_files_to_sandbox(client, env_id, binary_files)

        max_turns = 20
        current_turn = 0

        while current_turn < max_turns:
            current_turn += 1

            if getattr(interaction, "status", "") == "requires_action":
                steps = getattr(interaction, "steps", [])
                
                # [수정] 샌드박스 자체 도구 등 이미 완료된 function_result ID 수집
                executed_calls = set()
                for step in steps:
                    st_type = getattr(step, "type", "") or (step.get("type") if isinstance(step, dict) else "")
                    call_id = getattr(step, "call_id", None) or (step.get("call_id") if isinstance(step, dict) else None)
                    if st_type == "function_result" and call_id:
                        executed_calls.add(call_id)

                # [수정] 아직 처리되지 않은 클라이언트 전용 function_call만 선별
                pending_calls = []
                for step in steps:
                    st_type = getattr(step, "type", "") or (step.get("type") if isinstance(step, dict) else "")
                    s_id = getattr(step, "id", None) or (step.get("id") if isinstance(step, dict) else None)
                    if st_type == "function_call" and s_id not in executed_calls:
                        pending_calls.append(step)

                if pending_calls:
                    function_results = []
                    for call in pending_calls:
                        fn_name = getattr(call, "name", None) or (call.get("name") if isinstance(call, dict) else "")
                        fn_args = getattr(call, "arguments", None) or (call.get("arguments") if isinstance(call, dict) else {})
                        call_id = getattr(call, "id", None) or (call.get("id") if isinstance(call, dict) else "")

                        if isinstance(fn_args, str):
                            try:
                                fn_args = json.loads(fn_args)
                            except Exception:
                                fn_args = {}
                        elif not isinstance(fn_args, dict):
                            if hasattr(fn_args, "to_dict"):
                                fn_args = fn_args.to_dict()
                            elif hasattr(fn_args, "__dict__"):
                                fn_args = vars(fn_args)
                            else:
                                fn_args = {}

                        tool_result = {}
                        if fn_name == "save_blog_post":
                            tool_result = save_blog_post(
                                output_dir=OUTPUT_DIR,
                                filename=fn_args.get("filename", "blog_post.md"),
                                content=fn_args.get("content", "")
                            )
                        elif fn_name == "save_infographic":
                            tool_result = save_infographic(
                                output_dir=OUTPUT_DIR,
                                filename=fn_args.get("filename", "image"),
                                svg_content=fn_args.get("svg_content", "")
                            )
                        else:
                            # 커스텀 등록 도구가 아닌 서버 내부 도구는 무시
                            continue

                        # [수정] Google Interactions API 공식 표준 포맷으로 result 텍스트 파트 직렬화
                        function_results.append({
                            "type": "function_result",
                            "call_id": call_id,
                            "name": fn_name,
                            "result": [{"type": "text", "text": json.dumps(tool_result, ensure_ascii=False)}]
                        })

                    if not function_results:
                        print("  [안내] 처리할 클라이언트 도구 호출이 없어 에이전트 작업을 대기합니다...")
                        break

                    # 턴 간 급격한 토큰 소모 방지를 위한 5초 완충 딜레이
                    print("  [안내] API 분당 호출 한도 보호를 위해 5초간 대기합니다...")
                    time.sleep(5)

                    # [멀티턴 연결] 샌드박스 environment_id 추출 및 tools 재지정
                    current_env = _extract_environment_id(interaction, environment_param)

                    next_kwargs = {
                        "agent": agent_id,
                        "previous_interaction_id": interaction.id,
                        "environment": current_env,
                        "tools": all_tools,  # 👈 [핵심 수정] 2차 턴에서도 도구 목록 반드시 재전달
                        "input": function_results,
                        "store": True,       # 👈 세션 연속성 유지
                    }

                    if agent_config:
                        next_kwargs["agent_config"] = agent_config

                    interaction = create_interaction_with_retry(client, **next_kwargs)
                    continue
            
            break

        # [안정화] 최종 출력 텍스트 안전 추출
        output_text = getattr(interaction, "output_text", None)
        if not output_text:
            text_parts = []
            for step in getattr(interaction, "steps", []):
                st = getattr(step, "type", "") or (step.get("type") if isinstance(step, dict) else "")
                if st == "text":
                    val = getattr(step, "text", "") or (step.get("text") if isinstance(step, dict) else "")
                    if val:
                        text_parts.append(val)
            output_text = "\n\n".join(text_parts) if text_parts else str(interaction)

        print("\n[3/4] 에이전트 포스팅 작업 및 저장 완료!")
        print("=" * 60)
        print(output_text)
        print("=" * 60)

        print(f"\n[4/4] 결과 확인")
        print(f" 마크다운과 이미지 파일들이 '{OUTPUT_DIR}/' 폴더에 성공적으로 저장되었습니다.")

    except Exception as e:
        print(f"\n[오류 발생] {e}", file=sys.stderr)


if __name__ == "__main__":
    main()