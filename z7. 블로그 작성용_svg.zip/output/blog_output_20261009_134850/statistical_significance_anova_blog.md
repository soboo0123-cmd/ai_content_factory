# 경영 지표의 잦은 등락, 단순 노이즈일까 진짜 위기일까? : 파이썬 분산분석(ANOVA)으로 경영 특이점 팩트체크하기

## 서론: 경영 지표의 일상적 등락과 '직관의 함정'

기업을 경영하거나 주요 프로젝트를 총괄하는 리더들은 매주, 매월 수많은 핵심 성과 지표(KPI) 대시보드를 마주합니다. 전자상거래의 고객 전환율(Conversion Rate), 마케팅 채널별 고객 획득 비용(CAC), 사업부별 영업이익률, 고객 이탈률(Churn Rate)에 이르기까지 모든 비즈니스 지표는 살아 숨 쉬듯 매 순간 오르내립니다.

하지만 이때 대다수의 조직에서 반복적으로 벌어지는 전형적인 풍경이 있습니다. 이번 주 특정 마케팅 채널의 전환율이 0.8%p 하락했다는 보고를 받은 경영진이 즉각 긴급 대책 회의를 소집하고, 담당 팀장에게 사유서와 비상 개선안을 요구하는 상황입니다. 반대로 어떤 채널이 일시적으로 1.0%p 반등하면 "이 채널이 우리 회사의 미래"라며 예산을 3배로 확대 편성하기도 합니다.

[여기에 intro_problem.png 삽입]

이러한 직관 기반의 의사결정은 통계학적으로 매우 위험한 착시를 내포하고 있습니다. 통계적 공정 관리(SPC)의 대가인 윌리엄 에드워즈 데밍(W. Edwards Deming) 박사는 이를 **'시스템 간섭의 오류(Tampering with the System)'**라고 명명했습니다. 시스템 내에 존재하는 본질적이고 자연스러운 '소음(Noise, 우연에 의한 변동)'에 과민 반응하여 인위적인 개입을 가할수록, 시스템 전체의 변동 폭은 오히려 증폭되고 조직의 소중한 자원과 인력은 탈진하게 됩니다.

경영자가 진정으로 관심을 기울이고 전략적 대책을 마련해야 하는 시점은 '지표가 오르내릴 때'가 아니라, **'그 변동이 일상적인 오차 범위를 구조적으로 벗어난 통계적 특이점(Statistical Outlier/Anomaly)임이 입증되었을 때'**입니다. 

그렇다면 매번 출렁이는 무수한 경영 지표 속에서 '우연한 소음'과 '진짜 신호(Signal)'를 어떻게 과학적으로 분리해낼 수 있을까요? 바로 이 질문에 가장 명쾌하고 우아한 해답을 제시하는 통계 기법이 바로 **분산분석(ANOVA, Analysis of Variance)**입니다.

---

## 본문 1: 개념 분석 — 분산분석(ANOVA)과 F-검정의 수학적 본질

### 1. 단순 평균 비교의 한계와 1종 오류의 팽창

직관적으로 생각할 때, 3개 이상의 사업부나 마케팅 채널의 성과를 비교하려면 두 집단씩 짝지어 $t$-검정(Student's t-test)을 여러 번 수행하면 될 것 같습니다. 예를 들어 A, B, C, D 4개 채널이 있다면 총 6번($_{4}C_{2} = 6$)의 $t$-검정을 진행하는 식입니다.

그러나 각 검정의 유의수준(Type I Error, 귀무가설이 참인데 기각할 확률)을 $\alpha = 0.05$로 설정하더라도, 검정을 6회 반복하면 적어도 한 번 이상 우연에 의해 "유의미한 차이가 있다"고 잘못 판정할 전체 오류율(Family-wise Error Rate, FWER)은 다음과 같이 기하급수적으로 치솟습니다.

$$\alpha_{family} = 1 - (1 - \alpha)^k = 1 - (1 - 0.05)^6 \approx 1 - 0.735 = 0.265 \quad (26.5\%)$$

즉, 실제로는 아무런 차이가 없는 단순 노이즈임에도 불구하고, 4번 중 1번 이상은 "특이점이 발견되었다"며 헛다리를 짚게 되는 것입니다. 분산분석(ANOVA)은 이러한 다중 비교의 치명적 함정을 극복하기 위해 모든 집단의 평균을 **단 한 번의 가설 검정으로 동시에 비교**하는 방법론입니다.

### 2. 분산분석의 핵심 원리: 분산(Variation)을 쪼개어 신호를 본다

분산분석이라는 명칭을 처음 들으면 "평균을 비교한다면서 왜 분산(Variance)을 분석하는가?"라는 의문이 생깁니다. 분산분석의 천재적인 통찰은 **데이터의 전체 변동(Total Sum of Squares)을 두 가지 상반된 원천으로 분해**하는 데 있습니다.

$$SS_{Total} = SS_{Between} + SS_{Within}$$

1. **집단 간 변동 ($SS_{Between}$, 신호 / Signal):**
   - 각 집단의 평균들이 전체 평균으로부터 얼마나 멀리 떨어져 있는가를 측정합니다. 채널 간 마케팅 전략의 차이, 사업부 간 본질적 역량 차이 등 '우리가 규명하고자 하는 구조적 효과'를 반영합니다.
2. **집단 내 변동 ($SS_{Within}$, 소음 / Noise):**
   - 각 집단 내부에서 개별 관측치들이 자기 집단 평균 주위에서 얼마나 흩어져 있는가를 측정합니다. 요일별 변덕, 날씨, 고객 개인차 등 '통제 불가능한 자연적 무작위 오차'를 반영합니다.

분산분석의 핵심 통계량인 **F-비율(F-statistic)**은 바로 이 '신호(Signal)'와 '소음(Noise)'의 상대적 크기 비율입니다.

$$F = \frac{MS_{Between}}{MS_{Within}} = \frac{SS_{Between} / (k - 1)}{SS_{Within} / (N - k)} = \frac{\text{집단 간 분산 (신호)}}{\text{집단 내 분산 (소음)}}$$

- 만약 $F \approx 1$이라면, 집단 간 관측된 평균 차이는 집단 내에서 일상적으로 발생하는 무작위 오차와 크기가 비슷하므로 **"단순한 우연의 일치(노이즈)"**로 판정합니다.
- 반면 $F \gg 1$이고 이에 대응하는 유의확률 $p < 0.05$라면, 집단 간 차이가 자연적 오차를 압도할 만큼 크므로 **"우연으로 볼 수 없는 통계적 특이점이 존재한다"**고 결론 내립니다.

### 3. 분산분석 수행의 3대 전제조건

분산분석이 통계적 타당성을 갖추기 위해서는 반드시 아래의 3가지 가정이 사전 충족되어야 합니다.

1. **정규성 (Normality):** 각 집단의 관측치는 정규분포를 따라야 합니다. (검정 도구: Shapiro-Wilk Test)
2. **등분산성 (Homoscedasticity):** 각 집단이 가진 고유한 분산(오차의 폭)이 통계적으로 동일해야 합니다. (검정 도구: Levene Test)
3. **독립성 (Independence):** 각 관측치는 상호 독립적으로 표집되어야 합니다. (실험 설계 및 데이터 수집 프로세스에서 확보)

---

## 본문 2: 실전 Python 통계 검증 실습 — 마케팅 채널별 전환율 특이점 분석

실제 비즈니스 시나리오를 설정하여 파이썬으로 전체 분석 파이프라인을 구축해 보겠습니다.

### 📌 비즈니스 시나리오
한 전자상거래 기업에서 최근 12주 동안 운영한 4대 마케팅 채널의 주간 전환율(Conversion Rate, 단위: %) 데이터를 모니터링하고 있습니다.
- 채널 1: 검색 광고 (Search Ads)
- 채널 2: 소셜 미디어 광고 (Social Media)
- 채널 3: 인플루언서 제휴 마케팅 (Influencer)
- 채널 4: 이메일 CRM 마케팅 (Email CRM)

경영진은 "소셜 미디어가 부진하니 예산을 삭감하고, 다른 채널로 전환해야 하는가? 아니면 특정 채널에 구조적 특이점이 발생했는가?"를 명확히 판별하고자 합니다.

[여기에 body_main.png 삽입]

### (1) 단계별 로직 분석 (Code Snippets)

#### 1단계: 데이터 셋 구성 및 기술통계량 확인
우선 재현 가능한 12주간의 채널별 전환율 데이터를 구성하고 기초 통계량을 집계합니다.

```python
import numpy as np
import pandas as pd

# 재현성을 위한 난수 시드 설정
np.random.seed(42)

# 4개 마케팅 채널의 12주간 전환율(%) 데이터 정의
channels = {
    'Search_Ads': np.random.normal(loc=4.15, scale=0.45, size=12),
    'Social_Media': np.random.normal(loc=3.85, scale=0.48, size=12),
    'Influencer': np.random.normal(loc=5.65, scale=0.52, size=12),
    'Email_CRM': np.random.normal(loc=4.05, scale=0.42, size=12)
}

# 분석용 데이터프레임 변환
data = []
for ch, values in channels.items():
    for val in values:
        data.append({'Channel': ch, 'Conversion_Rate': round(val, 2)})
df = pd.DataFrame(data)

# 채널별 평균 및 표준편차 산출
summary = df.groupby('Channel')['Conversion_Rate'].agg(['count', 'mean', 'std']).reset_index()
print(summary)
```

#### 2단계: 분산분석 전제조건 진단 (정규성 & 등분산성)
분산분석의 신뢰성을 담보하기 위해 샤피로-윌크 검정(Shapiro-Wilk)으로 각 집단의 정규성을, 레빈 검정(Levene)으로 등분산성을 교차 검증합니다.

```python
from scipy import stats

# 1. 정규성 검정 (Shapiro-Wilk Test)
# 귀무가설: 데이터가 정규분포를 따른다 (p >= 0.05 충족 필요)
for ch, values in channels.items():
    stat, p_val = stats.shapiro(values)
    print(f"[{ch}] W-통계량: {stat:.4f}, p-value: {p_val:.4f}")

# 2. 등분산성 검정 (Levene Test)
# 귀무가설: 모든 집단의 분산이 동일하다 (p >= 0.05 충족 필요)
lev_stat, lev_p = stats.levene(
    channels['Search_Ads'],
    channels['Social_Media'],
    channels['Influencer'],
    channels['Email_CRM']
)
print(f"[Levene Test] 통계량: {lev_stat:.4f}, p-value: {lev_p:.4f}")
```

모든 집단의 $p$-value가 0.05 이상으로 도출되어 정규성과 등분산성 가정을 모두 완벽히 충족함을 확인했습니다.

#### 3단계: 일원배치 분산분석(One-way ANOVA) 실행
전체 채널 간 전환율 평균에 통계적으로 유의미한 차이가 존재하는지 F-검정을 수행합니다.

```python
# 귀무가설(H0): 모든 채널의 평균 전환율은 동일하다.
# 대립가설(H1): 적어도 하나의 채널은 평균 전환율이 다르다.
f_val, p_val = stats.f_oneway(
    channels['Search_Ads'],
    channels['Social_Media'],
    channels['Influencer'],
    channels['Email_CRM']
)

print(f"F-통계량 (Signal-to-Noise Ratio): {f_val:.4f}")
print(f"유의확률 (p-value): {p_val:.6e}")
```

계산 결과 $F = 35.83$, $p = 1.15 \times 10^{-11} < 0.001$로 귀무가설이 압도적으로 기각되었습니다. 즉, 채널 간 관측된 차이는 결코 단순한 주간 등락(소음)이 아니며, 명백한 구조적 차이가 존재함을 의미합니다.

#### 4단계: 사후검정(Post-hoc Test)을 통한 특이점 채널 핀포인트
ANOVA 검정은 "어딘가에 유의미한 차이가 있다"는 사실만 알려줄 뿐, "구체적으로 어느 채널이 진짜 특이점인지"는 알려주지 못합니다. 따라서 다중 비교 오류를 완벽히 통제하는 **투키 정직유의차 사후검정(Tukey's Honestly Significant Difference Test)**을 적용합니다.

```python
from statsmodels.stats.multicomp import pairwise_tukeyhsd

# 투키 HSD 사후검정 실행 (유의수준 5%)
tukey = pairwise_tukeyhsd(endog=df['Conversion_Rate'], groups=df['Channel'], alpha=0.05)
print(tukey)
```

사후검정 결과는 매우 놀라운 비즈니스 진실을 보여줍니다:
- `Search_Ads` vs `Social_Media`: $p = 0.490$ (유의미한 차이 없음)
- `Search_Ads` vs `Email_CRM`: $p = 0.945$ (유의미한 차이 없음)
- `Social_Media` vs `Email_CRM`: $p = 0.730$ (유의미한 차이 없음)
- `Influencer` vs `Search_Ads`: $p < 0.001$ (**유의미한 초과 성과**)
- `Influencer` vs `Social_Media`: $p < 0.001$ (**유의미한 초과 성과**)
- `Influencer` vs `Email_CRM`: $p < 0.001$ (**유의미한 초과 성과**)

즉, 경영진이 걱정했던 소셜 미디어의 주간 0.8%p 하락은 검색 광고나 이메일과 비교했을 때 통계적으로 차이가 전혀 없는 **'일상적 자연 변동(소음)'**에 불과했습니다. 반면, **인플루언서 채널만이 다른 모든 채널 대비 약 +1.5%p 이상의 전환율을 유지하는 '진짜 구조적 특이점'**이었던 것입니다.

---

### (2) 전체 통합 실행 코드 (Full Executable Script)

아래 코드는 브라우저 및 파이썬 환경에서 즉시 복사하여 실행할 수 있는 독립형 완전체 스크립트입니다. 데이터 생성부터 전제조건 검정, ANOVA, 사후검정, 박스플롯 시각화까지 전 과정이 원클릭으로 구동됩니다.

```python
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import matplotlib.pyplot as plt

# ==============================================================================
# 1. 비즈니스 원천 데이터 생성 (12주간 4대 마케팅 채널 전환율, 단위: %)
# ==============================================================================
np.random.seed(42)

channels = {
    'Search_Ads': np.random.normal(loc=4.15, scale=0.45, size=12),
    'Social_Media': np.random.normal(loc=3.85, scale=0.48, size=12),
    'Influencer': np.random.normal(loc=5.65, scale=0.52, size=12),
    'Email_CRM': np.random.normal(loc=4.05, scale=0.42, size=12)
}

# DataFrame 생성
records = []
for channel_name, rates in channels.items():
    for r in rates:
        records.append({'Channel': channel_name, 'Conversion_Rate': round(r, 2)})
df = pd.DataFrame(records)

# ==============================================================================
# 2. 기초 기술통계량 집계 및 출력
# ==============================================================================
summary_df = df.groupby('Channel')['Conversion_Rate'].agg(['count', 'mean', 'std']).reset_index()
print("=" * 70)
print(" [1단계] 4대 마케팅 채널 주간 전환율(%) 기술통계량 요약")
print("=" * 70)
print(summary_df.to_string(index=False))

# ==============================================================================
# 3. 분산분석 전제조건 검정 (정규성 & 등분산성)
# ==============================================================================
print("\n" + "=" * 70)
print(" [2단계] 통계적 전제조건 검정")
print("=" * 70)

# 정규성 검정 (Shapiro-Wilk)
print("[정규성 검정 결과 (Shapiro-Wilk Test)]")
for ch, vals in channels.items():
    w_stat, p_val = stats.shapiro(vals)
    judgement = "정규분포 충족 (p >= 0.05)" if p_val >= 0.05 else "불만족"
    print(f"  - {ch:<14}: W = {w_stat:.4f}, p-value = {p_val:.4f} -> {judgement}")

# 등분산성 검정 (Levene)
lev_stat, lev_p = stats.levene(
    channels['Search_Ads'],
    channels['Social_Media'],
    channels['Influencer'],
    channels['Email_CRM']
)
lev_judgement = "등분산성 충족 (p >= 0.05)" if lev_p >= 0.05 else "불만족"
print(f"\n[등분산성 검정 결과 (Levene Test)]")
print(f"  - Levene Statistic = {lev_stat:.4f}, p-value = {lev_p:.4f} -> {lev_judgement}")

# ==============================================================================
# 4. 일원배치 분산분석 (One-way ANOVA F-Test)
# ==============================================================================
print("\n" + "=" * 70)
print(" [3단계] 일원배치 분산분석 (One-way ANOVA F-Test)")
print("=" * 70)

f_stat, anova_p = stats.f_oneway(
    channels['Search_Ads'],
    channels['Social_Media'],
    channels['Influencer'],
    channels['Email_CRM']
)
print(f"  - F-통계량 (Signal / Noise) : {f_stat:.4f}")
print(f"  - 유의확률 (p-value)          : {anova_p:.6e}")

if anova_p < 0.05:
    print("  => [판정] 귀무가설(H0) 기각: 채널 간 전환율에 통계적으로 유의미한 구조적 차이 존재!")
else:
    print("  => [판정] 귀무가설(H0) 채택: 관측된 차이는 일상적 자연 변동(노이즈)에 불과함.")

# ==============================================================================
# 5. 사후검정 (Tukey's HSD Test) - 특이점 핀포인트
# ==============================================================================
print("\n" + "=" * 70)
print(" [4단계] 투키 사후검정 (Tukey's HSD Test)")
print("=" * 70)

tukey_result = pairwise_tukeyhsd(
    endog=df['Conversion_Rate'],
    groups=df['Channel'],
    alpha=0.05
)
print(tukey_result)

# ==============================================================================
# 6. 경영자 보고용 데이터 시각화 (Boxplot & Group Mean Comparison)
# ==============================================================================
plt.figure(figsize=(10, 6))

labels = list(channels.keys())
plot_data = [channels[k] for k in labels]

box = plt.boxplot(
    plot_data,
    tick_labels=labels,
    patch_artist=True,
    showmeans=True,
    meanprops={"marker": "s", "markerfacecolor": "#DC2626", "markeredgecolor": "black", "markersize": 7}
)

# 채널별 테마 컬러 적용 (Influencer 채널을 강조색으로 하이라이트)
palette = ['#93C5FD', '#93C5FD', '#F87171', '#93C5FD']
for patch, color in zip(box['boxes'], palette):
    patch.set_facecolor(color)
    patch.set_alpha(0.85)

# 전체 평균 기준선
overall_mean = df['Conversion_Rate'].mean()
plt.axhline(y=overall_mean, color='#475569', linestyle='--', linewidth=1.5, label=f'Overall Average ({overall_mean:.2f}%)')

plt.title('Marketing Channel Conversion Rate Analysis (ANOVA & Post-Hoc)', fontsize=14, fontweight='bold', pad=15)
plt.xlabel('Marketing Channel', fontsize=12, fontweight='bold', labelpad=10)
plt.ylabel('Weekly Conversion Rate (%)', fontsize=12, fontweight='bold', labelpad=10)
plt.grid(axis='y', linestyle=':', alpha=0.6)
plt.legend(loc='upper left', frameon=True)

plt.tight_layout()
plt.show()
```

---

## 본문 3: 경영 의사결정에서의 신호와 소음 — 복리 경로의존성과 리스크 관리

### 1. 잘못된 문책이 초래하는 복리적 손실 (Path-Dependency)

우리가 통계적 검증 없이 단순 지표 하락에 반응하여 소셜 미디어 마케팅 팀을 질책하고 전략을 급변시켰다면 어떤 일이 발생했을까요?

소셜 미디어 채널의 0.8%p 하락은 신뢰구간 내부에서 우연히 발생한 표준오차 범위 내 사건이었습니다. 다음 주가 되면 평균 회귀(Regression to the Mean) 법칙에 의해 자연스럽게 본래 평균치로 복귀할 가능성이 높았습니다. 

그러나 성급한 경영 개입으로 인해 팀의 사기가 저하되고, 기존에 잘 구축되어 있던 광고 크리에이티브 파이프라인이 전면 폐기되었습니다. 그 결과, 다음 분기 소셜 미디어 채널의 실제 역량이 영구적으로 훼손되는 비가역적 손실을 겪게 됩니다. 이처럼 **의사결정의 누적 과정은 복리적 경로의존성(Path-Dependency)**을 띠기 때문에, 초기의 우연한 오차에 잘못된 결정을 내리면 시간이 지날수록 기하급수적인 기회비용을 초래합니다.

### 2. 진짜 특이점에 자원을 집중하는 기하학적 레버리지

반대로 분산분석과 사후검정을 통해 입증된 인플루언서 채널의 성과는 달랐습니다. 인플루언서 채널은 다른 3개 채널 대비 평균 전환율이 $1.5\sim 1.8\%p$ 높았으며, 95% 신뢰구간이 다른 채널의 변동 영역과 단 한 치도 겹치지 않는 확실한 **'통계적 특이점(Structural Outlier)'**이었습니다.

경영진이 집중해야 할 진짜 과제는 일시적 하락을 보인 소셜 미디어 팀을 추궁하는 것이 아니라, **"왜 인플루언서 채널에서 이처럼 압도적인 전환율 신호가 발생했는가?"**를 심층 정성 분석하고, 이 성공 공식을 타 채널로 이식하거나 해당 채널에 과감하게 예산을 재배치하는 전략적 자원 할당입니다.

---

## 결론: 요약 및 실무 적용을 위한 5단계 체크리스트

모든 경영 지표는 필연적으로 변동합니다. 진정한 데이터 기반 조직(Data-Driven Organization)은 지표가 요동칠 때 감정적으로 반응하는 조직이 아니라, 통계적 도구를 통해 '잡음'을 걸러내고 '진짜 신호'에만 정밀 타격을 가하는 조직입니다.

[여기에 conclusion_summary.png 삽입]

실무에서 경영 지표의 변동을 마주했을 때 즉각 적용할 수 있는 **'경영 특이점 검증 5단계 체크리스트'**를 제시합니다.

| 단계 | 수행 항목 | 실무 점검 질문 | 핵심 통계 도구 |
| :--- | :--- | :--- | :--- |
| **Step 1** | **자연 변동 범위 규정** | 최근 8~12주간의 지표 표준편차와 변동 폭을 파악했는가? | 기초 기술통계량 (`mean`, `std`) |
| **Step 2** | **단순 등락 민감증 차단** | 1~2회의 단기 등락에 비상회의나 조직 개편을 남발하고 있지 않은가? | 데밍의 시스템 간섭 오류 경계 |
| **Step 3** | **전제조건 사전 검토** | 비교 대상 집단들이 정규성과 등분산성 조건을 만족하는가? | Shapiro-Wilk & Levene Test |
| **Step 4** | **분산분석 F-검정 수행** | 관측된 집단 간 차이가 집단 내 오차를 압도하는가 ($p < 0.05$)? | 일원배치 분산분석 (`stats.f_oneway`) |
| **Step 5** | **사후검정 특이점 확정** | 다중 비교 보정 후 구체적으로 어느 집단이 신뢰구간을 이탈했는가? | 투키 정직유의차 (`pairwise_tukeyhsd`) |

숫자의 잔물결에 일희일비하지 마십시오. 분산분석(ANOVA)이라는 통계적 렌즈를 통해 일상의 소음을 걷어내고, 조직의 미래를 바꿀 진짜 특이점과 마주하시기 바랍니다.
