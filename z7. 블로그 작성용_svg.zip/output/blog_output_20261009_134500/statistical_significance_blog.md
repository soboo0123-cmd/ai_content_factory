# 경영지표의 오르내림, 언제 대책을 세워야 할까? — 일원배치 분산분석(ANOVA)과 파이썬 실전 검정

## 1. 서론: 매번 오르내리는 경영지표, 과연 위기일까요?

매일 아침 대시보드를 열어보는 경영자와 팀장들에게 가장 피 마르는 순간은 **"지표가 또 떨어졌을 때"** 혹은 **"갑자기 껑충 뛰었을 때"**입니다. 매출액, 전환율(CR), 고객 만족도(CSAT), 주간 활성 사용자(WAU) 등 비즈니스의 모든 지표는 매주, 매일 끊임없이 오르내립니다.

하지만 여기서 근본적인 의문이 생깁니다. **"이 변동이 정말로 경영자가 관심을 갖고 대책을 마련해야 하는 '유의미한 특이점'인가요, 아니면 자연스러운 노이즈(Noise)인가요?"**

많은 기업에서 단순 전주 대비 증감률(예: "이번 주 매출이 3.5% 하락했습니다!")만 보고 즉각적인 마케팅 예산 조정이나 조직 개편에 착수하곤 합니다. 그러나 통계적 검정 없이 직관에만 의존해 움직리면, 우연히 발생한 일시적 등락에 과잉 대응하여 소중한 리소스만 낭비하게 됩니다. 이럴 때 필요한 가장 강력한 통계적 도구가 바로 **분산분석(ANOVA, Analysis of Variance)**입니다.

[여기에 intro_problem.png 삽입]

---

## 2. 본문 1: 단순 직관의 함정과 분산분석(ANOVA)의 개념

### 2.1 왜 t-검정이 아니라 분산분석(ANOVA)인가요?
두 집단 간의 평균 차이를 비교할 때는 흔히 Student's t-test를 사용합니다. 하지만 현대 비즈니스 환경은 강남점, 홍대점, 판교점, 온라인몰 등 **3개 이상의 복수 채널이나 마케팅 캠페인**을 동시에 운영하는 경우가 대부분입니다.

만약 채널이 4개라면, 이를 두 개씩 짝지어 총 6번의 t-검정을 수행하면 어떻게 될까요? 통계학에서 다중 검정(Multiple Comparisons)을 반복할수록 **제1종 오류(Type I Error, 우연히 차이가 없는데 차이가 있다고 잘못 판단할 확률)**가 5%(`α = 0.05`)보다 훨씬 높아집니다. 4개 채널을 비교할 때 누적 오류 확률은 무려 약 26%까지 치솟습니다.

### 2.2 분산분석(ANOVA)의 핵심 원리
분산분석은 이름과 달리 **분산(Variance)**을 비교하여 **평균(Mean)**의 차이를 검정하는 기법입니다.
- **그룹 간 분산 (Between-Group Variance):** 채널 간 성과 차이로 인해 발생하는 변동
- **그룹 내 분산 (Within-Group Variance):** 개별 채널 내부에서 주차별로 발생하는 자연스러운 노이즈

이 두 분산의 비율을 나타내는 **F-통계량(F-statistic)**을 계산하여, 그룹 간 차이가 우연에 의한 것인지 통계적으로 유의미한지 판정합니다.
- **귀무가설 ($H_0$):** 모든 채널의 평균 성과 지표는 동일하다. (차이가 없다)
- **대립가설 ($H_1$):** 최소한 하나 이상의 채널은 평균 성과에 유의미한 차이가 있다.

---

## 3. 본문 2: 실전 Python 통계 검증 실습

실제 4개 마케팅 채널(검색광고, SNS마케팅, 제휴파트너, 이메일)의 주간 매출 성장률 데이터를 가정하고, 파이썬을 통해 일원배치 분산분석과 사후분석을 수행해 보겠습니다.

[여기에 body_main.png 삽입]

### 3.1 단계별 로직 분석 (Code Snippets)

#### ① 데이터 준비 및 기술 통계량 산출
먼저 4개 채널별로 6주간 수집된 주간 매출 성장률 데이터를 정의하고, 각 채널의 평균과 표준편차를 확인합니다.

```python
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import matplotlib.pyplot as plt

# 1. 가상 데이터 생성 (채널별 6주 관측)
np.random.seed(42)
channels = ['검색광고', 'SNS마케팅', '제휴파트너', '이메일']
data = {
    'Channel': np.repeat(channels, 6),
    'GrowthRate': np.concatenate([
        np.random.normal(5.2, 1.2, 6),  # 검색광고 (평균 5.2%)
        np.random.normal(8.5, 1.5, 6),  # SNS마케팅 (평균 8.5%)
        np.random.normal(4.8, 1.1, 6),  # 제휴파트너 (평균 4.8%)
        np.random.normal(5.0, 1.3, 6)   # 이메일 (평균 5.0%)
    ])
}
df = pd.DataFrame(data)

# 그룹별 요약 통계
print(df.groupby('Channel')['GrowthRate'].agg(['count', 'mean', 'std']))
```

#### ② 일원배치 분산분석(ANOVA) 및 사후분석(Tukey's HSD) 수행
`scipy.stats.f_oneway`와 `statsmodels`를 이용해 F-통계량과 p-value를 산출하고, 어느 채널 간에 구체적인 차이가 있는지 Tukey 사후분석을 진행합니다.

```python
# ANOVA 검정
f_val, p_val = stats.f_oneway(
    df[df['Channel'] == '검색광고']['GrowthRate'],
    df[df['Channel'] == 'SNS마케팅']['GrowthRate'],
    df[df['Channel'] == '제휴파트너']['GrowthRate'],
    df[df['Channel'] == '이메일']['GrowthRate']
)
print(f"F-statistic: {f_val:.4f}, p-value: {p_val:.5f}")

# 사후분석 (Tukey HSD)
tukey = pairwise_tukeyhsd(endog=df['GrowthRate'], groups=df['Channel'], alpha=0.05)
print(tukey)
```

---

### 🚀 3.2 전체 통합 실행 코드 (Full Executable Script)

아래의 전체 코드는 브라우저 환경(Pyodide) 및 로컬 파이썬 환경에서 외부 파일 의존성 없이 단독으로 즉시 실행할 수 있습니다. `[▶ 실행해보기]` 버튼을 클릭하여 통계 검정 결과와 시각화 그래프를 직접 확인해보세요!

```python
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import matplotlib.pyplot as plt

# 1. 데이터셋 정의 (4개 채널 주간 성장률)
np.random.seed(42)
channels = ['검색광고', 'SNS마케팅', '제휴파트너', '이메일']
data = {
    'Channel': np.repeat(channels, 6),
    'GrowthRate': np.concatenate([
        np.random.normal(5.2, 1.2, 6),
        np.random.normal(8.5, 1.5, 6),
        np.random.normal(4.8, 1.1, 6),
        np.random.normal(5.0, 1.3, 6)
    ])
}
df = pd.DataFrame(data)

print("=== [1] 채널별 기술 통계 ===")
summary_stats = df.groupby('Channel')['GrowthRate'].agg(['count', 'mean', 'std'])
print(summary_stats)

# 2. 일원배치 분산분석 (One-Way ANOVA)
f_val, p_val = stats.f_oneway(
    df[df['Channel'] == '검색광고']['GrowthRate'],
    df[df['Channel'] == 'SNS마케팅']['GrowthRate'],
    df[df['Channel'] == '제휴파트너']['GrowthRate'],
    df[df['Channel'] == '이메일']['GrowthRate']
)
print(f"\n=== [2] ANOVA 검정 결과 ===")
print(f"F-statistic: {f_val:.4f}")
print(f"p-value: {p_val:.5f}")
if p_val < 0.05:
    print("판정: 귀무가설 기각 (채널 간 유의미한 성과 차이가 존재합니다!)")
else:
    print("판정: 귀무가설 채택 (채널 간 유의미한 차이가 없습니다.)")

# 3. Tukey HSD 사후분석
print("\n=== [3] Tukey HSD 사후분석 결과 ===")
tukey = pairwise_tukeyhsd(endog=df['GrowthRate'], groups=df['Channel'], alpha=0.05)
print(tukey)

# 4. 시각화 (박스플롯)
plt.figure(figsize=(9, 5))
colors = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B']
box = plt.boxplot([df[df['Channel'] == ch]['GrowthRate'] for ch in channels], 
                  labels=channels, patch_artist=True)

for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)

plt.title('Marketing Channel Weekly Growth Rate Distribution (ANOVA)', fontsize=14, fontweight='bold', pad=15)
plt.xlabel('Marketing Channels', fontsize=12)
plt.ylabel('Growth Rate (%)', fontsize=12)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
```

---

## 4. 본문 3: 복리 경로의존성과 확률적 시사점

경영 지표를 관리할 때 단기적 변동에 일희일비하지 말아야 하는 또 다른 이유는 **복리(Compounding)와 경로의존성(Path Dependency)**의 법칙 때문입니다.

- **노이즈에 대한 과잉 대응의 위험:** 매주 발생하는 ±1~2%의 무작위 변동에 맞춰 캠페인을 중단하거나 예산을 급격히 재배치하면, 오히려 시스템의 관성(Momentum)을 깨뜨리고 장기적 복리 성장을 저해합니다.
- **분산분석의 전략적 가치:** ANOVA를 통해 진정으로 유의미한 차이를 보이는 채널(예: 위 예제에서 평균 8.5%를 기록한 SNS마케팅)을 정확히 식별해내면, 경영자는 불확실한 감이 아닌 수학적 신뢰를 바탕으로 한곳에 자원을 집중할 수 있습니다.

---

## 5. 결론 및 실무 체크리스트

모든 경영지표가 매번 오르내리는 것은 당연한 현상입니다. 중요한 것은 그 변동이 단순한 노이즈인지, 대책을 요구하는 진짜 특이점인지 판별하는 능력입니다. 오늘 살펴본 일원배치 분산분석(ANOVA)을 실무에 도입하여 객관적인 데이터 기반 의사결정 체계를 구축해 보세요.

[여기에 conclusion_summary.png 삽입]

### 💡 경영 지표 관리를 위한 실무 체크리스트
1. **노이즈와 신호 분리:** 일시적인 주간 등락에 과잉 대응하여 마케팅 예산을 낭비하지 마십시오.
2. **분산분석(ANOVA) 도입:** 3개 이상 부서·채널 간 비교 시 다중 t-검정 대신 ANOVA를 활용해 제1종 오류를 예방하세요.
3. **데이터 기반 자원 집중:** p-value와 Tukey HSD 사후분석으로 유의미한 성과 창출 영역을 특정하고 전략적으로 투자하세요.
