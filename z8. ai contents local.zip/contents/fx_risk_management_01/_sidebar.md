﻿* [🏠 환 위험 관리](home.md)

* **01 환 위험 기초**
  * [1.1 환 위험이란?](contents/fx_risk_management_01/sec_01/sub_01_01_v1.md)
  * [1.2 총손실한도 설정](contents/fx_risk_management_01/sec_01/sub_01_02_v1.md)
  * [1.3 최대손실가능금액(VaR) 산출](contents/fx_risk_management_01/sec_01/sub_01_03_v1.md)
  * [1.3 환 리스크 관리 기법](contents/fx_risk_management_01/sec_01/sub_01_04_v1.md)
